import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import App from './App';
import calculatorReducer from './reducers';
import { createStore } from 'redux';
import { Provider } from 'react-redux';

let store = createStore(calculatorReducer);

ReactDOM.render(
<Provider store={store}>
  <App/>
</Provider>
, document.getElementById('root'));