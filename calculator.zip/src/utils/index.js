export const calculation=(calcArray,calcResult)=>
{
    if(isNaN(calcArray[calcArray.length-1]))
    {
        return calcResult;
    }
    const operatorFunction={
        '+':(a,b)=>
        {
            return a+b;
        },
        '-':(a,b)=>
        {
            return a-b;
        },
        '*':(a,b)=>
        {
            return a*b;
        },
        '/':(a,b)=>
        {
            return a/b;

        },
        'sqaure':(a)=>
        {
          return a*a;
        },
        'sign':(a)=>
        {
          if(a>0)
          {
            return -a;
          }
          else{return +a;}
        },
        'sqaureroot':(a)=>
        {
          let b=Math.sqrt(a);
          return b;
        }

    };
let calcString=calcArray.join('');
let calcArrayUpdated = calcString.split(/(\+|-|\*|\/)/g);

// Set default result to 0
let result = 0;
let operator = '+';

for (let i = 0; i < calcArrayUpdated.length; i++) {
 
  let item = calcArrayUpdated[i];

  let isOperator = /(\+|-|\*|\/)/.test(item);

  if (isOperator) {
    operator = item;
  } else {
    result = operatorFunction[operator](result, parseInt(item));
  }
}

return result;
}

export const addValueToCalculation = (value, currentState) => {
currentState = [...currentState];

// List of operators to check for 
let operatorValues = ['*', '/', '+', '-','sign','square','squareroot'];

if (typeof value !== 'number' && !operatorValues.includes(value)) {
  return currentState;
}

if (operatorValues.includes(value) && !currentState.length) {
  return currentState;
}

let lastVal = currentState[currentState.length-1];

// Test is last value is an operator
let lastValIsOperator = operatorValues.includes(lastVal);

// Test is current value is an operator
let currentValIsOperator = operatorValues.includes(value);

// Check if last val in array is an operator
// Then replace it if new value is an operator
if(lastValIsOperator && currentValIsOperator){
  // Clone the state so we can replace the value
  // Replace last operator with new operator
  currentState[currentState.length-1] = value;
  
  // Break out of the function
  return currentState;
}

return [...currentState, value];
}

