
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { updateCalculation, clearCalculation } from './actions';
import CalcButton from './components/CalcButtons';

class App extends Component {
constructor()
{
  super()
  this.state={
    result:''
  }
}
  componentDidMount() {
    // Force scroll on the display
    // I do this on mount in case reducer is already populated
    this._forceScrollOnDisplay();
  }
  
  componentDidUpdate() {
    // Force scroll on the display
    // this function gets called on component update
    this._forceScrollOnDisplay();
  }

  // Replace the operator chars add a span for styling
  // and replace division and multiplication symbols
  _replaceChars(value) {
    value = value.join("");
    value = value.replace(/\//g, '<span class="operatorStyle">÷</span>');
    value = value.replace(/\*/g, '<span class="operatorStyle">×</span>');
    value = value.replace(/\+/g, '<span class="operatorStyle">+</span>');
    value = value.replace(/-/g, '<span class="operatorStyle">-</span>');
    return value;
  }

  _forceScrollOnDisplay() {
    // Force scroll on div, put a value in here
    // instead of calculating the offset
    // This keeps the latest numbers in display
    this.refs.calculationDisplay.scrollLeft = 10000;
    this.refs.resultDisplay.scrollLeft = 10000;
  }
  showScien(id)
  {
   
  let s = document.getElementById(id);

       	s.style.display = (s.style.display === 'none') ? 'block' : 'none';
  }
 sign(a)
 {
   if(a>0)
   {
     
this.setState({result:-a})
   }
   else{this.setState({result:-a})}
 } 
 square(a)
 {
  this.setState({result:a*a})
 }
 squareroot(a)
 {
  this.setState({result:Math.sqrt(a)})
 }
themeDark(id)
{
 let b=document.getElementById(id);
 b.className='darkTheme'
}

equal(r)
{
  console.log(`r${r}`)
  return r;
}
themeLight(id)
{
 let b=document.getElementById(id);
 b.className='lightTheme'
}
  render() {
 let a=this.props.calculation;
 let result=this.props.result;

    return (
        <div className='calculator' id="calc">
          <div className='calculator-results'>
            <div ref='calculationDisplay' className='calculationDisplay' dangerouslySetInnerHTML={{ __html: this.props.calculation.length ? this._replaceChars(this.props.calculation) : 0 }} />
            <div ref='resultDisplay' className='resultDisplay'>{result}</div>
          </div>
          
         
          <div className='calculator-inputs-row'>
            <CalcButton value={1} />
            <CalcButton value={2} />
            <CalcButton value={3} />
            <CalcButton value='+' htmlCode="43" additionalClass="operator" />
         
          </div>
          
          <div className='calculator-inputs-row'>
            <CalcButton value={4} />
            <CalcButton value={5} />
            <CalcButton value={6} />
            <CalcButton value='-' htmlCode="8722" additionalClass="operator" />
           
          </div>
          <div className='calculator-inputs-row'>
            <CalcButton value={7} />
            <CalcButton value={8} />
            <CalcButton value={9} />
            <CalcButton value='*' htmlCode="215" additionalClass="operator" />
          </div>
          <div className='calculator-inputs-row'>
          <button className='clear' onClick={() => this.props.clearCalculation()}>Clear</button>
            <CalcButton value={0}  />
            <CalcButton value="=" htmlCode="61" additionalClass="operator" onClick={()=>this.equal(result)} />
            <CalcButton value="/" htmlCode="247" additionalClass="operator" />
          </div>
          <div className='calculator-inputs-row'>
          <button className='scientific' onClick={() => this.showScien('scien')}>scientific Mode</button>
          <div id="scien" style={{display:'none'}}>
          <CalcButton  htmlCode="177" additionalClass="operator" onClick={()=>this.sign(a)} />
          <CalcButton  htmlCode="178" additionalClass="operator" onClick={()=>this.square(a)} />
          <CalcButton htmlCode="8730" additionalClass="operator" onClick={()=>this.squareroot(a)} />
          </div>
          </div>
          <div className='calculator-inputs-row'>
          <button className='theme' onClick={()=>this.themeDark('calc')}>Dark Theme</button>
          <button className='theme' onClick={()=>this.themeLight('calc')}>Light Theme</button>
          </div>
        </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  updateCalculation: (inputValue, currentState, currentResult) => dispatch(updateCalculation(inputValue, currentState, currentResult)),
  clearCalculation: () => dispatch(clearCalculation())
});

const mapStateToProps = (state) => ({
  calculation: state.calculation,
  result: state.result
});

export default connect(mapStateToProps, mapDispatchToProps)(App);
